#include <gtk/gtk.h>


void
on_ajoutAdmin_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
;

void
on_modifierAd_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerAd_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_HOME_focus                          (GtkWidget       *objet_graphique,
                                        GtkDirectionType  direction,
                                        gpointer         user_data);

void
on_admin_set_focus                     (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_table_row_activated                 (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_sendr_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reclamationtv_row_activated         (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
