#include <stdio.h>
#include <stdlib.h>
#include <time.h>

////////////////////////////
void someone (char ok1[20],int N1,int N2 ,int N3) {
char FINAL [300];
srand(time(NULL));
int A = rand()*256;
sprintf(FINAL,"%d %s %d/%d/%d",A,ok1,N1,N2,N3);
FILE*f;
f=fopen("/home/achref/Vidéos/skytravel00/src/clients.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",FINAL);//écriture dans le fichier
}
fclose(f); //fermeture du fichier
///////////////////
}

