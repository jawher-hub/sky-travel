void someone (char ok1[20],int N1,int N2 ,int N3);
