#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <time.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "someone.h"
#include "who.h"
#include "reserver.h"
#include "facturef.h"
#include "ajoutplane.h"
#include "cataloguez.h"
#include <stdio.h>
#include <string.h>
int verif(char nom[], char prenom[]){
FILE*f;
f=fopen("/home/achref/Vidéos/skytravel00/src/clients.txt","r");
char Nom[20]; char Prenom[20];
char role[20]; char s1[20];
char s2[20]; char s3[20];
if(f !=NULL) {
while(fscanf(f,"%s %s %s %s %s %s",s3,Nom,Prenom,role,s1,s2)!=EOF){
 //parcours du fichier;
printf("%s %s %s \n",Nom,Prenom,s1);
if ((strcmp(nom,Nom)==0) && (strcmp(Prenom,prenom)==0))
{if (strcmp(s1,"agent")==0) return 1;
if (strcmp(s1,"client")==0) return 2;}}
} return 0;
}

void
on_recherche_facture_client_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_creation_code_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"window5");
aller_allerretour_window=lookup_widget(button,"acceil");
client=create_window5();
gtk_widget_show(client);
}


void
on_recherche_code_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"window7");
aller_allerretour_window=lookup_widget(button,"gestion_factures_agent");
gtk_widget_destroy(aller_allerretour_window);
client=create_window7();
gtk_widget_show(client);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *achref,*aguel;
achref=lookup_widget(button,"gestion_factures_agent");
gtk_widget_destroy(achref);
aguel=create_rejoindreespacewindow();
gtk_widget_show(aguel);
}


void
on_confirmation_1_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rejoindreespace_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"rejoindreespacewindow");
aller_allerretour_window=lookup_widget(button,"acceil");
gtk_widget_destroy(aller_allerretour_window);
client=create_rejoindreespacewindow();
gtk_widget_show(client);
}


void
on_rejoindrecathalogue_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"rejoindrecathaloguewindow");
aller_allerretour_window=lookup_widget(button,"acceil");
gtk_widget_destroy(aller_allerretour_window);
client=create_rejoindrecathaloguewindow();
gtk_widget_show(client);
}


void
on_creeuncompte_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"creeuncomptewindow");
aller_allerretour_window=lookup_widget(button,"acceil");
gtk_widget_destroy(aller_allerretour_window);
client=create_creeuncomptewindow();
gtk_widget_show(client);
}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"acceil");
aller_allerretour_window=lookup_widget(button,"creeuncomptewindow");
gtk_widget_destroy(aller_allerretour_window);
client=create_acceil();
gtk_widget_show(client);
}


void
on_connexion_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
//1 = agent
//2 = client
GtkWidget *loginwindow , *agent, *aller_allerretour_window;
GtkWidget *entry10, *entry11, *WPlabel;
char login[20]; char password [20];
entry10=lookup_widget(button,"entry3");
entry11=lookup_widget(button,"entry4");
WPlabel=lookup_widget(button,"label38");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(entry11)));
////////////////
int x=verif(login,password);

////////////////////
if(x==1){
who (login,password,x);
agent=lookup_widget(button,"gestion_factures_agent");
loginwindow=lookup_widget(button,"rejoindreespacewindow");
gtk_widget_destroy(loginwindow);
agent=create_gestion_factures_agent();
gtk_widget_show(agent);}
if(x==2){
who (login,password,x);
aller_allerretour_window=lookup_widget(button,"espaceclient");
loginwindow=lookup_widget(button,"rejoindreespacewindow");
gtk_widget_destroy(loginwindow);
aller_allerretour_window=create_espaceclient();
gtk_widget_show(aller_allerretour_window);}
char tast[20];
sprintf(tast,"%d",x);
if(x==0){gtk_label_set_text(WPlabel,"wrong pass / login ");}
}


void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *aller;
GtkWidget *retour;
GtkWidget *date;
GtkWidget *Bebe;
GtkWidget *enfant;
GtkWidget *adulte;
GtkWidget *class;
GtkWidget *error;
///////////////////////////////////////
aller=lookup_widget(button,"entry5");
retour=lookup_widget(button,"entry6");
date=lookup_widget(button,"entry7");
class=lookup_widget(button,"combobox1");
Bebe=lookup_widget(button,"jourcreate");
enfant=lookup_widget(button,"moiscreate");
adulte=lookup_widget(button,"anneecreate");
error=lookup_widget(button,"errorclientmessage");
///////////////////////////////////
int B; int Ad; int E;
char A [500]; char R[500];
char D [500]; char C [500];
char S [500];
B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Bebe));
Ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adulte));
E=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(enfant));
strcpy(D,gtk_combo_box_get_active_text(GTK_COMBO_BOX(class)));
strcpy(C,gtk_entry_get_text(GTK_ENTRY(date)));
strcpy(A,gtk_entry_get_text(GTK_ENTRY(aller)));
strcpy(R,gtk_entry_get_text(GTK_ENTRY(retour)));
//////////////////////////////////
if (strcmp(A,"")==0) 
{gtk_label_set_text(error,"choisir informations correcte");}
else {
if (strcmp(R,"")==0) 
{gtk_label_set_text(error,"choisir informations correcte");}
else {
if (strcmp(C,"")==0) 
{gtk_label_set_text(error,"choisir informations correcte");}
else{printf("%s %s %s %d %d %d",A,R,D,B,E,Ad);
sprintf(S,"%s %s %s %s",A,R,C,D);
someone(S,B,E,Ad);
sprintf(S,"bienvenue %s chez sky travel",A);
gtk_label_set_text(error,S);}}}
}



void
on_espaceagent_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espaceadmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espaceclient_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestionhotel_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"window2");
aller_allerretour_window=lookup_widget(button,"espaceclient");
gtk_widget_destroy(aller_allerretour_window);
client=create_window2();
gtk_widget_show(client);
}


void
on_gestionvol_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"window1");
aller_allerretour_window=lookup_widget(button,"espaceclient");
gtk_widget_destroy(aller_allerretour_window);
client=create_window1();
gtk_widget_show(client);
}


void
on_gestionreservation_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"window3");
aller_allerretour_window=lookup_widget(button,"espaceclient");
gtk_widget_destroy(aller_allerretour_window);
client=create_window3();
gtk_widget_show(client);
}


void
on_leavecatalogue_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"acceil");
aller_allerretour_window=lookup_widget(button,"rejoindrecathaloguewindow");
gtk_widget_destroy(aller_allerretour_window);
client=create_acceil();
gtk_widget_show(client);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *client;
client=lookup_widget(button,"rejoindrecathaloguewindow");
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
treeview1=lookup_widget(client,"treeview1");
afficher_plane(treeview1,"/home/achref/Vidéos/skytravel00/src/catalogue.txt"); 
}


void
on_retour12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"acceil");
aller_allerretour_window=lookup_widget(button,"rejoindreespacewindow");
gtk_widget_destroy(aller_allerretour_window);
client=create_acceil();
gtk_widget_show(client);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
//recherche client de vol aller retour
GtkWidget *aller;
GtkWidget *retour;
GtkWidget *dateA;
GtkWidget *dateB;
GtkWidget *Bebe;
GtkWidget *enfant;
GtkWidget *adulte;
GtkWidget *class;
GtkWidget *error;
///////////////////////////////////////
aller=lookup_widget(button,"combobox3");
retour=lookup_widget(button,"combobox4");
dateA=lookup_widget(button,"entry10");
dateB=lookup_widget(button,"entry11");
class=lookup_widget(button,"combobox2");
Bebe=lookup_widget(button,"spinbutton1");
enfant=lookup_widget(button,"spinbutton2");
adulte=lookup_widget(button,"spinbutton3");
error=lookup_widget(button,"label47");
///////////////////////////////////////
int B; int Ad; int E;
char A [50]; char R[50];
char D [50]; char C [10]; char DD [50];
B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Bebe));
Ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adulte));
E=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(enfant));
strcpy(C,gtk_combo_box_get_active_text(GTK_COMBO_BOX(class)));
strcpy(A,gtk_combo_box_get_active_text(GTK_COMBO_BOX(aller)));
strcpy(R,gtk_combo_box_get_active_text(GTK_COMBO_BOX(retour)));
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));
strcpy(DD,gtk_entry_get_text(GTK_ENTRY(dateB)));

///////////////////////////////////////
if (strcmp(DD,"")==0) strcpy(DD,"pas_de_retour");
if (strcmp(A,"")!=0 && strcmp(D,"")!=0 && strcmp(DD,"")!=0){
int x = B+Ad+E;
char result [1000];
sprintf(result,"%s %s %s %s %s",A,R,D,DD,C);
reserver(result,B,Ad,E);
gtk_label_set_text(error,result);
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"facturewindow");
aller_allerretour_window=lookup_widget(button,"window1");
client=create_facturewindow();
gtk_widget_show(client);}
else
gtk_label_set_text(error,"choisir informations correcte");
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent,*agent2, *client;
client=lookup_widget(button,"espaceclient");
aller_allerretour_window=lookup_widget(button,"window1");
agent=lookup_widget(button,"window2");
agent2=lookup_widget(button,"window3");
gtk_widget_destroy(aller_allerretour_window);
gtk_widget_destroy(agent);
gtk_widget_destroy(agent2);
client=create_espaceclient();
gtk_widget_show(client);

}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
FILE*f;
char PROMO[3000];
char Nom[20]; char Prenom[20];char Role[20];
char Nom1[20]; char Prenom1[20];char Role1[20];
char Nom2[20]; char Prenom2[20]; char k[30];int Role2;
char R[1000];
f=fopen("/home/achref/Vidéos/skytravel00/src/reservationscurrent.txt","r");//ouvertur du fichier en mode lecture
if(f !=NULL) {
while(fscanf(f,"%d %s %s %s %s %s %s %s %s %s \n",&Role2,Nom,Prenom,Role,Nom1,Prenom1,Role1,Nom2,Prenom2,k)!=EOF){ //parcours du fichier;
}}
fclose(f);
///////////////
GtkWidget *error;
GtkWidget *code;
char DD [500];
char CC [500];
code=lookup_widget(button,"label48");
error=lookup_widget(button,"label19");
GtkWidget *dateB;
dateB=lookup_widget(button,"code_promo_entry");
strcpy(DD,gtk_entry_get_text(GTK_ENTRY(dateB)));
/////////////
int test=0;
if (strcmp(DD,"")==0){
sprintf(R,"destination :%s vers %s \n date d'aller : %s \n date retour :%s \n classe :%s \n nb bebe : %s \n nb enfants : %s \n nb Adultes :%s \n montant a payer :%d dt \n",Nom,Prenom,Role,Nom1,Prenom1,Role1,Nom2,Prenom2,Role2);
gtk_label_set_text(error,R);}
else
{
///////////////
f=fopen("/home/achref/Vidéos/skytravel00/src/promotions.txt","r"); //ouvrir un fichier en mode ajout
if(f!=NULL) { //si le fichier est ouvert
fscanf(f,"%s",PROMO);//écriture dans le fichier
if(strcmp(DD,PROMO)==0) test=1;
}
//////////////
if (test == 1)
{
printf("%d",test);
int A = rand();
while((A<200)||(A>3000)) {
A=A/10;}
A=A/100;
sprintf(CC,"vous avez effectuer un promos de %d % !",A);
int EE = (Role2/100)*(100-A);
sprintf(R,"destination :%s vers %s \n date d'aller : %s \n date retour :%s \n classe :%s \n nb bebe : %s \n nb enfants : %s \n nb Adultes :%s \n montant a payer :%d dt \n montant a payer aprés reduction :%d dt \n",Nom,Prenom,Role,Nom1,Prenom1,Role1,Nom2,Prenom2,Role2,EE);
gtk_label_set_text(error,R);
gtk_label_set_text(code,CC);
}else 
{
printf("%d",test);
sprintf(R,"destination :%s vers %s \n date d'aller : %s \n date retour :%s \n classe :%s \n nb bebe : %s \n nb enfants : %s \n nb Adultes :%s \n montant a payer :%d dt \n",Nom,Prenom,Role,Nom1,Prenom1,Role1,Nom2,Prenom2,Role2);
gtk_label_set_text(error,R);
gtk_label_set_text(code,"désolé, coupon de redution invalide");
}
fclose(f);}

}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
//recherche client de vol aller retour
GtkWidget *aller;
GtkWidget *retour;
GtkWidget *dateA;
GtkWidget *dateB;
GtkWidget *Bebe;
GtkWidget *enfant;
GtkWidget *adulte;
GtkWidget *class;
GtkWidget *error;
///////////////////////////////////////
aller=lookup_widget(button,"combobox5");
retour=lookup_widget(button,"combobox6");
dateA=lookup_widget(button,"entry12");
dateB=lookup_widget(button,"entry13");
class=lookup_widget(button,"combobox7");
Bebe=lookup_widget(button,"spinbutton4");
enfant=lookup_widget(button,"spinbutton5");
adulte=lookup_widget(button,"spinbutton6");
error=lookup_widget(button,"label57");
///////////////////////////////////////
int B; int Ad; int E;
char A [50]; char R[50];
char D [50]; char C [100]; char DD [50];
B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Bebe));
Ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adulte));
E=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(enfant));
strcpy(C,gtk_combo_box_get_active_text(GTK_COMBO_BOX(class)));
strcpy(A,gtk_combo_box_get_active_text(GTK_COMBO_BOX(aller)));
strcpy(R,gtk_combo_box_get_active_text(GTK_COMBO_BOX(retour)));
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));
strcpy(DD,gtk_entry_get_text(GTK_ENTRY(dateB)));

///////////////////////////////////////
if (strcmp(A,"")!=0 && strcmp(D,"")!=0 && strcmp(DD,"")!=0){
int x = B+Ad+E;
char result [1000];
sprintf(result,"%s %s %s %s %s",A,R,D,DD,C);
reserver(result,B,Ad,E);
gtk_label_set_text(error,result);
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"facturewindow");
aller_allerretour_window=lookup_widget(button,"window1");
client=create_facturewindow();
gtk_widget_show(client);}
else
gtk_label_set_text(error,"choisir informations correcte");
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
/*char D[100000];
//////////////////////////////////////*/
window2=lookup_widget(button,"window3");
label=lookup_widget(button,"label60");
/*/////////////////////////////////////
//gtk_label_set_text(label,"");
bilel("/home/coca/gladeProject/skytravel3/src/reservations.txt",label);
//gtk_label_set_text(label,D);*/
char text [100000];
strcpy(text,"1 ");
char D[1000];
FILE *f=fopen ("/home/achref/Vidéos/skytravel00/src/reservations.txt","r");
int i=0;
int bilel=0;
char F[30];
int I=1;
while(fscanf(f,"%s",D)!=EOF){
i++;
if (bilel<1) {
if(i==11) {I++;sprintf(F,"\n %d-",I);bilel++;strcat(text,F); i=0;}
strcat(text,D);
strcat(text," ");
printf("%d \n",I);}//}
else {if(i==10) {I++;sprintf(F,"\n %d-",I);bilel++;strcat(text,F); i=0;}
strcat(text,D);
strcat(text," ");printf("%d \n",I);}
}
gtk_label_set_text(label,text);
}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
GtkWidget *Spinbutton;

char AA[100];
char FF[100];
//////////////////////////////////////
window2=lookup_widget(button,"window3");
label=lookup_widget(button,"label60");
Spinbutton=lookup_widget(button,"spinbutton7");
//////////////////////////////////////
int B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Spinbutton));
char k[20];
sprintf(k,"%d modifié",B);
facturef(B,AA,FF);
////////////////////////////////////
char D[300]; char DD[300];
GtkWidget *dateA;
GtkWidget *dateB;
dateA=lookup_widget(button,"entry14");
dateB=lookup_widget(button,"entry15");
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));
strcpy(DD,gtk_entry_get_text(GTK_ENTRY(dateB)));
if(strcmp(DD,"")==0)strcpy(D,"pas_de_retour");
//////////////////////////////
char FINAL [3000];
FILE*f;
if(strcmp(D,"")!=0){sprintf(FINAL,"%s %s %s %s",AA,D,DD,FF);f=fopen("/home/achref/Vidéos/skytravel00/src/reservations.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",FINAL);//écriture dans le fichier
}
gtk_label_set_text(label,k);}else gtk_label_set_text(label,"entrer des dates aller valides");
fclose(f);

}


void
on_button16_enter                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
GtkWidget *Spinbutton;
char D[100000];
char AA[100];
char FF[100];
//////////////////////////////////////
window2=lookup_widget(button,"window2");
label=lookup_widget(button,"label60");
Spinbutton=lookup_widget(button,"spinbutton7");
//////////////////////////////////////
int B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Spinbutton));
char k[20];
sprintf(k,"%d suprimée",B);
gtk_label_set_text(label,k);
achref(B,AA,FF);
printf("%s %s",AA,FF);
}


void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char D[300]; char DD[300];
GtkWidget *dateA;
GtkWidget *label;
dateA=lookup_widget(button,"entry16");
label=lookup_widget(button,"label69");
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));
FILE*f;
if(strcmp(D,"")!=0){f=fopen("/home/achref/Vidéos/skytravel00/src/promotions.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",D);//écriture dans le fichier
}
gtk_label_set_text(label,"code ajouté");}
else {gtk_label_set_text(label,"code non valide");}
fclose(f);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller;
GtkWidget *retour;
GtkWidget *dateA;
GtkWidget *dateB;
GtkWidget *Bebe;
GtkWidget *enfant;
GtkWidget *adulte;
GtkWidget *class;
GtkWidget *error;
///////////////////////////////////////
aller=lookup_widget(button,"combobox8");
retour=lookup_widget(button,"combobox10");
Bebe=lookup_widget(button,"spinbutton9");
enfant=lookup_widget(button,"spinbutton10");
adulte=lookup_widget(button,"spinbutton11");
error=lookup_widget(button,"label84");
dateA=lookup_widget(button,"entry17");
///////////////////////////////////////
int B; int Ad; int E;
char A [50]; char R[50]; char C[50];
char D [50];
B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Bebe));
Ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adulte));
E=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(enfant));
strcpy(A,gtk_combo_box_get_active_text(GTK_COMBO_BOX(aller)));
strcpy(R,gtk_combo_box_get_active_text(GTK_COMBO_BOX(retour)));
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));

///////////////////////////////////////
if (strcmp(R,"----------------")!=0 && strcmp(A,"----------------")!=0 && strcmp(D,"")!=0){
int x = B+Ad+E;
char result [1000];
sprintf(result,"%s %s %s",A,R,D);
cataloguez(result,B,Ad,E);
//printf("%s",result);
gtk_label_set_text(error,"catalogue ajouté !");
}
else
gtk_label_set_text(error,"choisir informations correcte");
}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
GtkWidget *Spinbutton;
char D[100000];
char AA[100];
char FF[100];
//////////////////////////////////////
window2=lookup_widget(button,"window7");
label=lookup_widget(button,"label83");
Spinbutton=lookup_widget(button,"spinbutton12");
//////////////////////////////////////
int B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Spinbutton));
char k[20];
sprintf(k,"%d suprimée",B);
gtk_label_set_text(label,k);
ajoutplane(B,AA,FF);
printf("%s %s",AA,FF);
}


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
GtkWidget *Spinbutton;

char AA[100];
char FF[100];
//////////////////////////////////////
window2=lookup_widget(button,"window7");
label=lookup_widget(button,"label83");
Spinbutton=lookup_widget(button,"spinbutton12");
//////////////////////////////////////
int B=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Spinbutton));
char k[20];
sprintf(k,"%d modifié",B);
ajoutplane(B,AA,FF);
////////////////////////////////////
char D[300]; char DD[300];
GtkWidget *dateA;
dateA=lookup_widget(button,"entry18");
strcpy(D,gtk_entry_get_text(GTK_ENTRY(dateA)));
//////////////////////////////
char FINAL [3000];
FILE*f;
if(strcmp(D,"")!=0){sprintf(FINAL,"%s %s %s",AA,D,FF);f=fopen("/home/achref/Vidéos/skytravel00/src/catalogue.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { 
fprintf(f,"%s \n",FINAL);//écriture dans le fichier
printf("%s \n",FINAL);
}
gtk_label_set_text(label,k);}else gtk_label_set_text(label,"entrer des dates aller valides");
fclose(f);

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aller_allerretour_window , *agent, *client;
client=lookup_widget(button,"gestion_factures_agent");
aller_allerretour_window=lookup_widget(button,"window7");
gtk_widget_destroy(aller_allerretour_window);
client=create_gestion_factures_agent();
gtk_widget_show(client);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *label;
/*char D[100000];
//////////////////////////////////////*/
window2=lookup_widget(button,"window7");
label=lookup_widget(button,"label83");
char text [100000];
strcpy(text,"1 ");
char D[1000];
FILE *f=fopen ("/home/achref/Vidéos/skytravel00/src/catalogue.txt","r");
int i=0;
int bilel=0;
char F[30];
int I=1;
while(fscanf(f,"%s",D)!=EOF){
i++;
if (bilel<1) {
if(i==7) {I++;sprintf(F,"\n %d-",I);bilel++;strcat(text,F); i=0;}
strcat(text,D);
strcat(text," ");
printf("%d \n",I);}//}
else {if(i==6) {I++;sprintf(F,"\n %d-",I);bilel++;strcat(text,F); i=0;}
strcat(text,D);
strcat(text," ");printf("%d \n",I);}
}
gtk_label_set_text(label,text);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *achref,*aguel;
achref=lookup_widget(button,"window6");
gtk_widget_destroy(achref);
aguel=create_gestion_factures_agent();
gtk_widget_show(aguel);
}


void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *achref,*aguel;
achref=lookup_widget(button,"gestion_factures_agent");
gtk_widget_destroy(achref);
aguel=create_window6();
gtk_widget_show(aguel);	
}


void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *achref,*aguel;
achref=lookup_widget(button,"espaceclient");
gtk_widget_destroy(achref);
aguel=create_rejoindreespacewindow();
gtk_widget_show(aguel);
}

