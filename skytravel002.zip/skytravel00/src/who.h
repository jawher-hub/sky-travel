void who (char nom[20], char prenom[20],int age);
